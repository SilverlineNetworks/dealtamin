<?php

namespace Cornford\Googlmapper\Exceptions;

class MapperSearchResultException extends MapperException
{
}
