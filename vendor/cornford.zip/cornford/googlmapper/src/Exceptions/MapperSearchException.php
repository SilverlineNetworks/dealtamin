<?php

namespace Cornford\Googlmapper\Exceptions;

class MapperSearchException extends MapperException
{
}
