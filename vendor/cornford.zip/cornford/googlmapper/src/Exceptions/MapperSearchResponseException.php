<?php

namespace Cornford\Googlmapper\Exceptions;

class MapperSearchResponseException extends MapperException
{
}
