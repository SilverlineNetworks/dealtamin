<?php

namespace Cornford\Googlmapper\Exceptions;

class MapperSearchResultMalformedException extends MapperException
{
}
