<?php

namespace Cornford\Googlmapper\Exceptions;

use Exception;

class MapperException extends Exception
{
}
