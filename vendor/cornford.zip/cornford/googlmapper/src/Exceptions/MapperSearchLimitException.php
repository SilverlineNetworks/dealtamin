<?php

namespace Cornford\Googlmapper\Exceptions;

class MapperSearchLimitException extends MapperException
{
}
