<?php

namespace Cornford\Googlmapper\Exceptions;

class MapperInstanceException extends MapperException
{
}
