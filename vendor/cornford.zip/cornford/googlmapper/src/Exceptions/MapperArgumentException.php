<?php

namespace Cornford\Googlmapper\Exceptions;

class MapperArgumentException extends MapperException
{
}
