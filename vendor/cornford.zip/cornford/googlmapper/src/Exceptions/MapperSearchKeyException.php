<?php

namespace Cornford\Googlmapper\Exceptions;

class MapperSearchKeyException extends MapperException
{
}
